<?php
namespace helpers\redirect;
 

class route{
    public static function go($value)
    {
        echo '<br> go to '.$value;
 
    }
}
