<?php

namespace bootstrap;

include ROOT . '/helpers/redirect.php';
include ROOT . '/libs/Controller.php';
include ROOT . '/libs/Core.php';
