<?php
define("ROOT", dirname(dirname(__FILE__)));